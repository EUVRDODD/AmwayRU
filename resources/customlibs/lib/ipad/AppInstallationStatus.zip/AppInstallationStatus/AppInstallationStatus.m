
@implementation AppInstallationStatus
+(BOOL) iSAppInstalled:(NSString *)url
{
    UIApplication *application = [UIApplication sharedApplication];
    
    NSURL *URL = [NSURL URLWithString:url];
    
    if([[UIDevice currentDevice].systemVersion floatValue] >= 10.0){
     
            BOOL success = [application openURL:URL];
            return success;
    }
    else{
        
        bool can = [application canOpenURL:URL];
        
        if(can){
            
            return YES;
            
        }else{
            return NO;
        }
        
    }
}

@end
