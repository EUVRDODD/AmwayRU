#import <Foundation/Foundation.h>

@interface AppInstallationStatus:NSObject
+(BOOL) iSAppInstalled:(NSString *)url;

@end
