//
//  TealiumWrapper.m
//  KRelease
//
//  Created by Arun Thallapelly on 12/20/17.
//

#import "TealiumWrapper.h"
#import <TealiumIOS/TealiumIOS.h>
#import <TealiumIOSLifecycle/TealiumIOSLifecycle.h>

@implementation TealiumWrapper

+(void)initSharedInstance:(NSString *)accountName
                  profile:(NSString *)profileName
                   target:(NSString *)environmentName
                      key:(NSString *)key{
    TEALConfiguration *tealConfig = [TEALConfiguration configurationWithAccount:accountName
                                                                        profile:profileName
                                                                    environment:environmentName
                                                                     datasource:@""];
    
    // Initialize with a unique key for this instance
    Tealium *tealium = [Tealium newInstanceForKey:key configuration:tealConfig];
}

+ (void) trackEvent:(NSString *)callType
                  customData:(NSString *)data
                      key:(NSString *)key{
    Tealium *tealium = [Tealium instanceForKey:key];
    NSError *error;
    NSData *dataDictionary = [data dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:dataDictionary
                                                                 options:kNilOptions
                                                                   error:&error];
    [tealium trackEventWithTitle:callType dataSources: jsonResponse];
}

+ (void) trackView:(NSString *)screenName customData:(NSString *)data key:(NSString *)key{
    Tealium *tealium = [Tealium instanceForKey:key];
    NSError *error;
    NSData *dataDictionary = [data dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:dataDictionary
                                                                 options:kNilOptions
                                                                   error:&error];
    [tealium trackViewWithTitle:screenName dataSources:jsonResponse];
}

@end
