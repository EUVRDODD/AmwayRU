//
//  TealiumWrapper.h
//  KRelease
//
//  Created by Arun Thallapelly on 12/20/17.
//

#import "VMAppDelegate.h"
#import <TealiumIOS/TealiumIOS.h>
#import <TealiumIOSLifecycle/TealiumIOSLifecycle.h>

@interface TealiumWrapper : VMAppDelegate


+(void)initSharedInstance:(NSString *)accountName
                  profile:(NSString *)profileName
                   target:(NSString *)environmentName
                      key:(NSString *)key;

+ (void) trackEvent:(NSString *)callType
                  customData:(NSString *)data
                         key:(NSString *)key;

+ (void) trackView:(NSString *)callType
                  customData:(NSString *)data
                         key:(NSString *)key;

@end
