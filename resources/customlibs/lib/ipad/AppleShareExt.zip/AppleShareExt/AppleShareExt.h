#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface AppleShareExt:NSObject
+(void) share:(NSString *)url;

@end
