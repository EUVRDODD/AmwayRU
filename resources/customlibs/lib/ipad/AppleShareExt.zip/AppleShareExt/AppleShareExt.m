#import "AppleShareExt.h"
@implementation AppleShareExt

+(void)share:(NSString *)url
{
	 NSURL *myWebsite = [NSURL URLWithString:url];
 
    NSArray *objectsToShare = @[myWebsite];
 
    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:objectsToShare applicationActivities:nil];
 
   /* NSArray *excludeActivities = @[UIActivityTypeAirDrop,
                                   UIActivityTypePrint,
                                   UIActivityTypeAssignToContact,
                                   UIActivityTypeSaveToCameraRoll,
                                   UIActivityTypeAddToReadingList,
                                   UIActivityTypePostToFlickr,
                                   UIActivityTypePostToVimeo];
 
    activityVC.excludedActivityTypes = excludeActivities;*/
    [[[[UIApplication sharedApplication]keyWindow]rootViewController]presentViewController:activityVC animated:YES completion:nil];
    //[self presentViewController:activityVC animated:YES completion:nil];
}

@end
