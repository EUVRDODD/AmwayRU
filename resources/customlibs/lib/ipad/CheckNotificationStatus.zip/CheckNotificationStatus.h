#import <Foundation/Foundation.h>

@interface CheckNotificationStatus : NSObject{

}

+ (BOOL)notificationServicesEnabled;

@end