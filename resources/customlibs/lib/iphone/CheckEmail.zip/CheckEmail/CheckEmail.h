#import <Foundation/Foundation.h>

@interface CheckEmail : NSObject{

}

+ (BOOL)canSendEmail;

@end