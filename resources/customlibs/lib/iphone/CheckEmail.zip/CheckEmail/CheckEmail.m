#import "CheckEmail.h"

@implementation CheckEmail

+ (BOOL)canSendEmail {
    BOOL isEnabled = NO;
    NSLog(@"OBJC main class");
    Class mainClass = (NSClassFromString(@"MFMailComposeViewController"));
    if(mainClass!=nil){
        NSLog(@"OBJC main class is not nil");
        if ([mainClass canSendMail]) {
            NSLog(@"OBJC main class can send email");
            isEnabled = YES;
        }
    }
       return isEnabled;
}
@end
