
#import "DownloadWrapper.h"
#import "Digital_Tool_Box-Swift.h"  //Need to change as per application name
#import "CallBack.h"
#import "lglobals.h"
#import "KonyUIContext.h"


@implementation DownloadWrapper

+ (id)sharedManager {
    
    static DownloadWrapper *sharedInstance = nil;

        static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (id)init {
    if (self = [super init]) {
    }
    return self;
}

-(void) setUpdateProgressCallBackObj:(CallBack *)cbUpdateProgressObj finishDownloadCallBackObj:(CallBack *)cbFinishDownloadObj{
    self.updateProgressCallBackObj = cbUpdateProgressObj;
    self.finishDownloadCallBackObj = cbFinishDownloadObj;
    self.swiftObj = [SearchViewController sharedInstance];
}

-(void)startDownload:(NSMutableDictionary *)track{
   
    [self.swiftObj initializeSession];
    NSURL *url = [[NSURL alloc] initWithString:[track objectForKey: @"url"]];
    [track setObject:url forKey:@"url"];
	[self.swiftObj downloadTappedWithTrack:track];
}
-(void)pauseDownload:(NSMutableDictionary *)track{
    [self.swiftObj initializeSession];
    NSURL *url = [[NSURL alloc] initWithString:[track objectForKey: @"url"]];
    [track setObject:url forKey:@"url"];
    [self.swiftObj pauseTappedWithTrack:track];
}
-(void)resumeDownload:(NSMutableDictionary *)track{
    [self.swiftObj initializeSession];
    NSURL *url = [[NSURL alloc] initWithString:[track objectForKey: @"url"]];
    [track setObject:url forKey:@"url"];
    [self.swiftObj resumeTappedWithTrack:track];
}
-(void)cancelDownload:(NSMutableDictionary *)track{
    [self.swiftObj initializeSession];
    NSURL *url = [[NSURL alloc] initWithString:[track objectForKey: @"url"]];
    [track setObject:url forKey:@"url"];
    [self.swiftObj cancelTappedWithTrack:track];
}
-(void)updateProgress:(NSDictionary *)track progress:(NSString *)progress{
    [self.updateProgressCallBackObj executeWithArguments:[[NSArray alloc]initWithObjects:track,progress,nil]];
}
-(void)updateDownloadComplete:(NSDictionary *)track filePath:(NSURL *)filePath{
    NSString* strFilePath = [filePath absoluteString];
    [self.finishDownloadCallBackObj executeWithArguments:[[NSArray alloc]initWithObjects:track,strFilePath,nil]];
}
-(void)openPdfFile:(NSString*)path{
    // Check if the file exists
    //BOOL isFound = [[NSFileManager defaultManager] fileExistsAtPath:path];
    //if (isFound) {
        UIDocumentInteractionController *viewer = [UIDocumentInteractionController interactionControllerWithURL:[NSURL URLWithString:path]];
        viewer.delegate = self;
        [viewer presentPreviewAnimated:YES];
    
   // }
}
-(void)playDownloadedVideo:(NSString*)uid{
	//[self.swiftObj initializeSession];
    [self.swiftObj playDownloadWithUid:uid];
}
-(NSString*)getDocumentDirectory:(NSDictionary*)track{
    @try {
        NSURL *url = [self.swiftObj contentFilePathFor:track];
        return  [url absoluteString];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception occured");
        return @"";
    }
    @finally {
        return @"";
    }
    
}
- (UIViewController *) documentInteractionControllerViewControllerForPreview: (UIDocumentInteractionController *) controller{
   // UIViewController *viewCon = [[UIViewController alloc]initWithNibName:nil bundle:nil];
    return [self topViewController] ;
}
-(UIViewController *)topViewController {
    return [self topViewControllerWithRootViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
}

-(UIViewController*)topViewControllerWithRootViewController:(UIViewController*)rootViewController {
    if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController* tabBarController = (UITabBarController*)rootViewController;
        return [self topViewControllerWithRootViewController:tabBarController.selectedViewController];
    } else if ([rootViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController* navigationController = (UINavigationController*)rootViewController;
        return [self topViewControllerWithRootViewController:navigationController.visibleViewController];
    } else if (rootViewController.presentedViewController) {
        UIViewController* presentedViewController = rootViewController.presentedViewController;
        return [self topViewControllerWithRootViewController:presentedViewController];
    } else {
        return rootViewController;
    }
}


@end
