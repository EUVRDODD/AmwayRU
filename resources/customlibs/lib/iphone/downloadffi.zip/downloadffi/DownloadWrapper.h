
#import <Foundation/Foundation.h>
#import "CallBack.h"
#import <UIKit/UIKit.h>

@interface DownloadWrapper:UIViewController<UIDocumentInteractionControllerDelegate>

@property (strong, retain) CallBack *updateProgressCallBackObj;
@property (strong, retain) CallBack *finishDownloadCallBackObj;

@property (nonatomic, retain) id swiftObj;


+ (id)sharedManager;
-(id)init;

-(void) setUpdateProgressCallBackObj:(CallBack *)cbUpdateProgressObj finishDownloadCallBackObj:(CallBack *)cbFinishDownloadObj;
-(void)startDownload:(NSMutableDictionary *)track;
-(void)pauseDownload:(NSMutableDictionary *)track;
-(void)resumeDownload:(NSMutableDictionary *)track;
-(void)cancelDownload:(NSMutableDictionary *)track;
-(void)updateProgress:(NSDictionary *)track progress:(NSString *)progress;
-(void)updateDownloadComplete:(NSDictionary *)track filePath:(NSURL *)filePath;
-(void)openPdfFile:(NSString*)path;
-(NSString*)getDocumentDirectory:(NSDictionary*)track;


//Not using the below method for now TODO:remove it later
-(void)playDownloadedVideo:(NSString*)uid;

@end
