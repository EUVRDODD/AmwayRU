/**
This is delegate to SearchViewController
 */

import Foundation
import UIKit

extension SearchViewController: URLSessionDownloadDelegate {

  // Stores downloaded file
  func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
    // 1
    guard let sourceURL = downloadTask.originalRequest?.url,
    let download = activeDownloads[sourceURL]
    else { return }
    activeDownloads[sourceURL] = nil
    // 2
    let destinationURL = localFilePath(for: download)
    print("filePath is \(destinationURL)")
    // 3
    let fileManager = FileManager.default
    try? fileManager.removeItem(at: destinationURL)
    do {
      try fileManager.copyItem(at: location, to: destinationURL)           
    } catch let error {
      print("Could not copy file to disk: \(error.localizedDescription)")
    }
    // 4
    
         download.track["url"] = sourceURL.absoluteString
        let downloadWrapper:DownloadWrapper = DownloadWrapper.sharedManager() as! DownloadWrapper
        downloadWrapper.updateDownloadComplete(download.track, filePath:destinationURL)
    self.urlSessionDidFinishEvents(forBackgroundURLSession: session)
        //TODO: update the view after downloading
    //}
  }

  // Updates progress info
  func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
    totalBytesExpectedToWrite: Int64) {

    //print("Download progress callback\(String(describing: downloadTask.originalRequest?.url))")
    //print("Active downloads are \(String(describing: activeDownloads))")
    // 1
    guard let url = downloadTask.originalRequest?.url,
      let download = activeDownloads[url]
    else {
        print("Download progress There are no active downloads so returning")
        return
    }
	//download.track["url"] = url.absoluteString
    download.progress = Float(totalBytesWritten) / Float(totalBytesExpectedToWrite)
    //download.track["dummyUrl"] = url.absoluteString
 
    //print("Download progress is \(download.progress)")
        let downloadWrapper:DownloadWrapper = DownloadWrapper.sharedManager() as! DownloadWrapper
        downloadWrapper.updateProgress(download.track, progress: String(format: "%.0f%%",  (download.progress) * 100))
    }
}
// MARK: - URLSessionDelegate

extension SearchViewController: URLSessionDelegate {
    // Standard background session handler
    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            session.getTasksWithCompletionHandler { (sessionDataTask, uploadData, downloadData) in
                let count:Int = sessionDataTask.count + uploadData.count + downloadData.count
                print("count is \(count)")
                if(count==0){
                    if let appDelegate = UIApplication.shared.delegate as? DTBAppDelegate,
                        let completionHandler = appDelegate.backgroundSessionCompletionHandler {
                        appDelegate.backgroundSessionCompletionHandler = nil
                        completionHandler()
                    }
                }
            }
        }
    }
}

