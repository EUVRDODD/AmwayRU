/**
 Sreenivas
 This is the main controller from where we will start download service
 **/
import UIKit
import AVKit
import AVFoundation
var sessionInit :Bool  = false;

@objc class SearchViewController: UIViewController {
  
  static let sharedInstance = SearchViewController()
  let downloadService = DownloadService()
  // Create downloadsSession here, to set self as delegate
    @available(iOS 8.0, *)
    lazy var downloadsSessions: URLSession = {
//    let configuration = URLSessionConfiguration.default
    let configuration = URLSessionConfiguration.background(withIdentifier: "bgSessionConfiguration")
    return URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
  }()
  // Get local file path: download task stores tune here; AV player plays it.
  let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
  func localFilePath(for download: Download) -> URL {
  //appendingPathComponent("google.com")
    let download_type:String = download.track["contentType"] as! String;
    let uid = download.track["UID"] as! String
    if(download_type == "video"){
        return documentsPath.appendingPathComponent(uid+".mp4")
    }else{
        return documentsPath.appendingPathComponent(uid+".pdf")
    }
  }
    func contentFilePath(for track: [String:Any]) -> URL {
        //appendingPathComponent("google.com")
        let download_type:String = track["contentType"] as! String;
        let uid = track["UID"] as! String
        if(download_type == "video"){
            return documentsPath.appendingPathComponent(uid+".mp4")
        }else{
            return documentsPath.appendingPathComponent(uid+".pdf")
        }
    }
    
  //TODO: Sreeni on init we will create a session
    
    /*
     + (id)sharedManager {
     static SomeManager *staticManager = nil;
     static dispatch_once_t onceToken;
     
     dispatch_once(&onceToken, ^{
     staticManager = [[self alloc] init];
     });
     return staticManager;
     }
 */
    @available(iOS 8.0, *)
    func initializeSession() {
        if(!sessionInit){
            downloadsSession = downloadsSessions
            sessionInit = true;
        }
    }
    @available(iOS 8.0, *)
    func playDownload(uid:  String) {
    DispatchQueue.main.async {
//        let playerViewController = AVPlayerViewController()
//        //playerViewController.entersFullScreenWhenPlaybackBegins = true
//        //playerViewController.exitsFullScreenWhenPlaybackEnds = true
//        //TODO url should be changed
//        let url = self.localFilePath(for: uid)
//        let player = AVPlayer(url: url)
//        playerViewController.player = player
//        UIApplication.shared.keyWindow?.rootViewController?.present(playerViewController, animated: true, completion: nil)
//        player.play()
    }
//    let url = localFilePath(for: track["url"] as! URL)
//    print("url before playing \(url)")
//    let playerAV = AVPlayer(url: url as URL)
//    let playerLayerAV = AVPlayerLayer(player: playerAV)
//    playerLayerAV.frame = self.view.bounds
//    self.view.layer.addSublayer(playerLayerAV)
//    playerAV.play()
  }


  func downloadTapped(track:  [String:Any]) {
    downloadService.startDownload(track);
  }

  func pauseTapped(track:  [String:Any]) {
    downloadService.pauseDownload(track)
  }
  
  func resumeTapped(track:  [String:Any]) {
    downloadService.resumeDownload(track)
  }
  
  func cancelTapped(track:  [String:Any]) {
    downloadService.cancelDownload(track)
  }
    
}

