/**
 Sreeni: This is Download service class which will maintain the list of items being downloaded,paused etc..
 **/

import Foundation

// Downloads contnet and stores in local file.
// Allows cancel, pause, resume download.
var activeDownloads: [URL: Download] = [:]
var downloadsSession: URLSession!

@objc class DownloadService :NSObject{

  // SearchViewController creates downloadsSession
  
  // MARK: - Download methods called by kony segment row click or detail page download button

  func startDownload(_ track:  [String:Any]) {
    // 1
    //let finalUrl = URL(string: track["url"]! as! String)
    //if finalUrl != nil{
        //print("url is \(String(describing: finalUrl))")
        let download = Download(track: track)
        // 2
        download.task = downloadsSession.downloadTask(with: track["url"] as! URL)
        // 3
        download.task!.resume()
        // 4
        download.isDownloading = true
        // 5
        activeDownloads[download.track["url"] as! URL] = download
    //}
    
  }

  func pauseDownload(_ track:  [String:Any]) {
    
    guard let download = activeDownloads[track["url"] as! URL]
    else {
		var tempTrack = track
		let url = track["url"] as! URL
		let urlString = url.absoluteString		
		tempTrack["url"] = urlString
		let downloadWrapper:DownloadWrapper = DownloadWrapper.sharedManager() as! DownloadWrapper
        downloadWrapper.updateDownloadComplete(tempTrack, filePath:URL(string:"ERROR"))
        print("No active downloads")
        return
        
    }
    if download.isDownloading {
//      download.task?.cancel(byProducingResumeData: { data in
//        download.resumeData = data
//      })
        download.task?.suspend()
      download.isDownloading = false
        }
  }

  func cancelDownload(_ track:  [String:Any]) {
    if let download = activeDownloads[track["url"]as! URL] {
      download.task?.cancel()
      activeDownloads[track["url"]as! URL] = nil
    }
  }

  func resumeDownload(_ track:  [String:Any]) {
    guard let download = activeDownloads[track["url"]as! URL]
    else {
		var tempTrack = track
		let url = track["url"] as! URL
		let urlString = url.absoluteString		
		tempTrack["url"] = urlString
        let downloadWrapper:DownloadWrapper = DownloadWrapper.sharedManager() as! DownloadWrapper
        downloadWrapper.updateDownloadComplete(track, filePath:URL(string:"ERROR"))
        print("Resume download There are no active downloads so returning");
        return
    }
//    if let resumeData = download.resumeData {
//      download.task = downloadsSession.downloadTask(withResumeData: resumeData)
//    } else {
//        print("No data to resume so downloading with the URL freshly \(String(describing: download.track["url"]))")
//      download.task = downloadsSession.downloadTask(with: download.track["url"]as! URL)
//    }
    download.task!.resume()
    download.isDownloading = true
    
  }

}
